#include "perso.h"
#include <stdio.h>

#define ACCELERATION 0.2
#define LIM_LEFT 50
#define LIM_RIGHT 1200  // <-- Limite droite élargie
#define GROUND_Y (550 + FRAME_HEIGHT)

#define FRAME_WIDTH 112
#define FRAME_HEIGHT 99

#define IDLE_LINE 0
#define WALK_LINE 1
#define RUN_LINE 2
#define JUMP_PREP_LINE 3
#define JUMP_AIR_LINE 4
#define JUMP_LAND_LINE 5

#define IDLE_FRAMES 8
#define WALK_FRAMES 8
#define RUN_FRAMES 8
#define JUMP_FRAMES 4

void init_perso(perso *p) {
    p->health = 0;
    p->score = 0;
    p->vie = 100;
    p->speed = 0;
    p->d = 1;
    p->jump = 0;
    p->pos.x = 50;
    p->pos.y = 550;
    p->sprite.x = 0;
    p->sprite.y = 0;
    p->state = IDLE;
    p->sprite_num = 0;
    p->image = IMG_Load("spritesheet.png");
    
    p->pos.w = FRAME_WIDTH;
    p->pos.h = FRAME_HEIGHT;
    p->sprite.w = FRAME_WIDTH;
    p->sprite.h = FRAME_HEIGHT;
}

void afficher_score(perso p, SDL_Surface *screen) {
    if (p.pos.x + p.pos.w > 0) {
        TTF_Font *font = NULL;
        font = TTF_OpenFont("score.ttf", 30);
        if (!font) font = TTF_OpenFont("arial.ttf", 30);
        if (!font) font = TTF_OpenFont("LiberationSans-Regular.ttf", 30);
        
        if (font) {
            SDL_Color vert = {0, 255, 0};
            char texte_score[50];
            sprintf(texte_score, "SCORE: %d", p.score);
            SDL_Surface *surface_score = TTF_RenderText_Solid(font, texte_score, vert);
            if (surface_score) {
                SDL_Rect position_score = {20, 20, surface_score->w, surface_score->h};
                SDL_BlitSurface(surface_score, NULL, screen, &position_score);
                SDL_FreeSurface(surface_score);
            }
            TTF_CloseFont(font);
        } else {
            printf("Erreur: Impossible de charger aucune police pour le score!\n");
        }
    }
}

void afficher_perso(perso p, SDL_Surface *screen) {
    SDL_BlitSurface(p.image, &p.sprite, screen, &p.pos);
}

void afficher_score_vie(perso p, SDL_Surface *screen, SDL_Surface *score_image) {
    if (p.pos.x + p.pos.w > 0 && score_image != NULL) {
        SDL_Rect pos;
        pos.x = screen->w - score_image->w - 10;
        pos.y = 10;
        SDL_BlitSurface(score_image, NULL, screen, &pos);
    }
}

void animer_perso(perso *p) {
    p->sprite_num++;
    int max_frames = 0;

    switch (p->state) {
        case IDLE:
            max_frames = IDLE_FRAMES;
            p->sprite.y = IDLE_LINE * FRAME_HEIGHT;
            break;
        case WALK:
            max_frames = WALK_FRAMES;
            p->sprite.y = WALK_LINE * FRAME_HEIGHT;
            break;
        case RUN:
            max_frames = RUN_FRAMES;
            p->sprite.y = RUN_LINE * FRAME_HEIGHT;
            break;
        case JUMP_PREP:
            max_frames = JUMP_FRAMES;
            p->sprite.y = JUMP_PREP_LINE * FRAME_HEIGHT;
            break;
        case JUMP_AIR:
            max_frames = JUMP_FRAMES;
            p->sprite.y = JUMP_AIR_LINE * FRAME_HEIGHT;
            break;
        case JUMP_LAND:
            max_frames = JUMP_FRAMES;
            p->sprite.y = JUMP_LAND_LINE * FRAME_HEIGHT;
            break;
    }

    if (p->sprite_num >= max_frames) {
        p->sprite_num = 0;
        if (p->state == JUMP_PREP) p->state = JUMP_AIR;
        else if (p->state == JUMP_LAND) p->state = IDLE;
    }

    p->sprite.x = p->sprite_num * FRAME_WIDTH;
}

void deplacer_perso(perso *p) {
    static int last_step = 0;
    Uint8 *keystate = SDL_GetKeyState(NULL);

    if (p->jump == 0) {
        if (keystate[SDLK_RIGHT]) {
            if (p->d == 1) {
                if (p->speed < 20)
                    p->speed += 1 + p->speed * ACCELERATION;
                p->state = RUN;
            } else {
                p->speed = 5;
                p->d = 1;
                p->state = WALK;
            }
            if (p->sprite_num != last_step) {
                p->score += SCORE_INCREMENT;
                last_step = p->sprite_num;
            }
        } else if (keystate[SDLK_LEFT]) {
            if (p->d == 2) {
                if (p->speed < 20)
                    p->speed += 1 + p->speed * ACCELERATION;
                p->state = RUN;
            } else {
                p->speed = 5;
                p->d = 2;
                p->state = WALK;
            }
            if (p->sprite_num != last_step) {
                p->score += SCORE_INCREMENT;
                last_step = p->sprite_num;
            }
        } else {
            p->state = IDLE;
            if (p->speed > 0) {
                p->speed -= 1;
                if (p->speed < 0) p->speed = 0;
            }
            last_step = 0;
        }
    }

    // Appliquer le déplacement
    if (p->d == 1) {
        p->pos.x += p->speed;
    } else {
        p->pos.x -= p->speed;
    }

    // Limites et arrêt
    if (p->pos.x < LIM_LEFT) {
        p->pos.x = LIM_LEFT;
        p->speed = 0;
    }
    if (p->pos.x > LIM_RIGHT) {
        p->pos.x = LIM_RIGHT;
        p->speed = 0;
    }
}

void jump_perso(perso *p) {
    Uint8 *keystate = SDL_GetKeyState(NULL);

    if (keystate[SDLK_UP] && p->jump == 0) {
        p->jump = 1;
        p->state = JUMP_PREP;
        p->sprite_num = 0;
    }

    if (p->jump > 0) {
        if (p->jump < 4) {
            p->jump++;
            p->pos.y -= 15;
            if (p->jump == 4) p->state = JUMP_AIR;
        } 
        else if (p->jump < 8) {
            p->jump++;
            p->pos.y += 15;  // équilibre parfait (montée/descente égale)
            if (p->jump == 8) {
                p->state = JUMP_LAND;
                p->sprite_num = 0;
            }
        } 
        else {
            p->jump = 0;
            p->state = IDLE;
            p->pos.y = GROUND_Y - FRAME_HEIGHT;  // Repositionnement EXACT au sol après saut
        }
    }
}

void prendre_degats(perso *p, int degats) {
    p->vie -= degats;
    if (p->vie < 0) p->vie = 0;
}

SDL_Surface* get_current_score_image(perso p, SDL_Surface* score_images[]) {
    if (score_images == NULL) return NULL;
    
    int index;
    if (p.vie >= 80) index = 4;
    else if (p.vie >= 60) index = 3;
    else if (p.vie >= 40) index = 2;
    else if (p.vie >= 20) index = 1;
    else index = 0;
    
    if (index < 0 || index >= SCORE_IMAGE_COUNT) return NULL;
    
    return score_images[index];
} 
