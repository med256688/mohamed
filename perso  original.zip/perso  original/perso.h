#ifndef PERSO_H
#define PERSO_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>

#define SCORE_IMAGE_COUNT 5
#define SCORE_INCREMENT 50

typedef enum {
    IDLE,
    WALK,
    RUN,
    JUMP_PREP,
    JUMP_AIR,
    JUMP_LAND
} SpriteState;

typedef struct {
    float velocity_y;
    int health;
    int score;
    int vie;
    int speed;
    int jump;
    int d; // 1 = droite, 2 = gauche
    SDL_Rect pos;
    SDL_Rect sprite;
    int sprite_num;
    SpriteState state;
    SDL_Surface *image;
} perso;

void init_perso(perso *p);
void afficher_score(perso p, SDL_Surface *screen);
void afficher_perso(perso p, SDL_Surface *screen);
void afficher_score_vie(perso p, SDL_Surface *screen, SDL_Surface *score_image);
void animer_perso(perso *p);
void deplacer_perso(perso *p);
void jump_perso(perso *p);
void prendre_degats(perso *p, int degats);
SDL_Surface* get_current_score_image(perso p, SDL_Surface* score_images[]);

#endif
