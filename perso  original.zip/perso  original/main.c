#include "perso.h"

void quitter(int *q) {
    Uint8 *touches = SDL_GetKeyState(NULL);
    if (touches[SDLK_ESCAPE]) *q = 1;
}

int main() {
    SDL_Init(SDL_INIT_EVERYTHING);
    TTF_Init();
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur SDL: %s\n", SDL_GetError());
        return 1;
    }
    
    // Initialisation TTF
    if (TTF_Init() < 0) {
        printf("Erreur TTF: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }

    SDL_Surface *ecran = SDL_SetVideoMode(1300, 700, 32, SDL_SWSURFACE);
    SDL_Surface *background = IMG_Load("bg.png");
    if (!background) printf("Erreur bg: %s\n", IMG_GetError());

    // Charger les images de score/vie
    SDL_Surface *score_images[SCORE_IMAGE_COUNT];
    for (int i = 0; i < SCORE_IMAGE_COUNT; i++) {
        char filename[20];
        sprintf(filename, "score vie %d.png", i+1);
        score_images[i] = IMG_Load(filename);
        if (!score_images[i]) {
            printf("Erreur chargement %s: %s\n", filename, IMG_GetError());
            return 1;
        }
    }

    perso p1;
    init_perso(&p1);

    int q = 0;
    while (!q) {
    SDL_PumpEvents();
    quitter(&q);
    SDL_Delay(60);

    SDL_BlitSurface(background, NULL, ecran, NULL);
    
    // Mise à jour du personnage
    jump_perso(&p1);
    deplacer_perso(&p1);
    animer_perso(&p1);
    
    // Affichages
    afficher_perso(p1, ecran);
    
    // Afficher l'image de vie
    SDL_Surface *current_score_image = get_current_score_image(p1, score_images);
    afficher_score_vie(p1, ecran, current_score_image);
    
    // Afficher le score numérique
    afficher_score(p1, ecran);

    SDL_Flip(ecran);
}
    // Libération de la mémoire
    for (int i = 0; i < SCORE_IMAGE_COUNT; i++) {
        SDL_FreeSurface(score_images[i]);
    }
    SDL_FreeSurface(background);
    SDL_FreeSurface(p1.image);
    TTF_Quit();
    SDL_Quit();
    return 0;
}
